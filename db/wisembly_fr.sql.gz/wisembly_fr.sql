-- MySQL dump 10.13  Distrib 5.5.29, for osx10.6 (i386)
--
-- Host: localhost    Database: wisembly_fr
-- ------------------------------------------------------
-- Server version	5.5.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cases` (
  `id` smallint(4) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `client_logo` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `illustration_image` varchar(255) DEFAULT NULL,
  `context` text NOT NULL,
  `usage` text NOT NULL,
  `results` text NOT NULL,
  `blockquote` text NOT NULL,
  `interviewed` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cases`
--

LOCK TABLES `cases` WRITE;
/*!40000 ALTER TABLE `cases` DISABLE KEYS */;
INSERT INTO `cases` VALUES (1,'la-poste','/static/images/clients/la-poste.png','Séminaires à La Poste','seminaries',NULL,'<ul>\r\n							<li>Une journée de séminaire annuel d’échanges de pratiques</li>\r\n							<li>120 managers de la direction financière de La Poste</li>\r\n							<li>Thème de travail: Réussir la décentralisation</li>\r\n						</ul>','<ul>\r\n							<li>Ouverture de la plateforme en amont pour recueillir les questions des \r\n	managers</li>\r\n							<li>Feedback en live via questions et commentaires envoyés depuis leur téléphone \r\n	(SMS et web) </li>\r\n							<li>Nuage de mots clés en live</li>\r\n							<li>Travail en sous-groupes de 15. Restitution et vote de la faisabilité de ses \r\n	propositions sous forme de sondage</li>\r\n						</ul>','<ul>\r\n							<li>95 questions réunies en amont</li>\r\n							<li>120 questions posées en direct</li>\r\n							<li>7 sondages en direct pour identifier les facteurs de succès</li>\r\n							<li>100% de participation</li>\r\n						</ul>','Au-delà de l’évidente dynamique ludique que crée Wisembly, il redonne à nos pratiques d’intervention un gain spectaculaire dans la capacité d’interaction.','Olivier Lagrée, Consultant DELOITTE'),(2,'sncf','/static/images/clients/sncf.png','Le Tchat du président à la SNCF','confcalls',NULL,'<ul>\r\n							<li>Une journée de séminaire annuel d’échanges de pratiques</li>\r\n							<li>120 managers de la direction financière de La Poste</li>\r\n							<li>Thème de travail: Réussir la décentralisation</li>\r\n						</ul>','<ul>\r\n							<li>Ouverture de la plateforme en amont pour recueillir les questions des \r\nmanagers</li>\r\n							<li>Feedback en live via questions et commentaires envoyés depuis leur téléphone \r\n(SMS et web)</li>\r\n							<li>Nuage de mots clés en live</li>\r\n							<li>Travail en sous-groupes de 15. Restitution et vote de la faisabilité de ses \r\npropositions sous forme de sondage</li>\r\n						</ul>','<ul>\r\n							<li>95 questions réunies en amont</li>\r\n							<li>120 questions posées en direct</li>\r\n							<li>7 sondages en direct pour identifier les facteurs de succès</li>\r\n							<li>100% de participation</li>\r\n						</ul>','Wisembly a créé un véritable u-turn dans la relation managériale de l\'entreprise. La solution nous accompagne dans toutes nos réunions.','Patrick Ropert, Directeur de la Communication, SNCF'),(3,'auchan','/static/images/clients/auchan.png','Conference Calls chez Auchan','confcalls',NULL,'<ul>\r\n							<li>Réunions bimensuelles de 2h d’avancement de projet</li> \r\n							<li>15 participants</li>\r\n							<li>Participants répartis dans différents sites et pays</li>\r\n						</ul>','<ul>\r\n							<li>Partage des slides en temps réel</li>\r\n							<li>Questions posées tout au long du call aux participants sur la plateforme</li>\r\n							<li>Réactions des participants en direct</li>\r\n							<li>Définition de l’agenda du prochain call à la fin du call</li>\r\n							<li>Partage des supports à la fin de la conférence</li>\r\n						</ul>','<ul>\r\n							<li>100% de participation</li>\r\n							<li>50 questions et idées en moyenne</li>\r\n							<li>3 documents partagés</li>\r\n						</ul>','Le pilotage des questions live et évaluations permet d\'aboutir facilement et rapidement à des décisions partagées, co-construites, là où la conversation téléphonique seule renvoie souvent l\'animateur à sa solitude.','Emmanuel Le Bouille, Directeur Innovation, AUCHAN'),(4,'hec','/static/images/clients/hec.png','Formations à HEC','trainings',NULL,'<ul>\r\n							<li>6 sessions de 3h de cours</li>\r\n							<li>35 étudiants</li>\r\n							<li>Intervenants extérieurs, présentations de cas</li>\r\n						</ul>','<ul>\r\n							<li>Mise en ligne des supports de cours sur la plateforme que les étudiants \r\ntéléchargent entre chaque session</li>\r\n							<li>Intervention des étudiants pendant les présentations des autres et apport de \r\nleurs contributions</li>\r\n							<li>Evaluation du niveau de connaissances et de progression des étudiants sur \r\nWisembly</li>\r\n							<li>Réponses à certaines questions sur la plateforme</li>\r\n						</ul>','<ul>\r\n							<li>944 questions et commentaires, 4007 likes sur ces questions</li>\r\n							<li>60 réponses à des questions directement sur la plateforme</li>\r\n							<li>20 quiz durant les sessions</li>\r\n							<li>2 évaluations du cours + 2 tests de connaissance</li>\r\n							<li>50 documents partagés</li>\r\n						</ul>','Wisembly est un boostier de ROI des formations et de l\'enseignement. Cela devient le \"le manuel interactif\" qui accompagne l\'ensemble des participants, en communauté avec leurs formateurs.','Georges-Edouard Dias, Professeur à HEC');
/*!40000 ALTER TABLE `cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `features_event`
--

DROP TABLE IF EXISTS `features_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features_event` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features_event`
--

LOCK TABLES `features_event` WRITE;
/*!40000 ALTER TABLE `features_event` DISABLE KEYS */;
INSERT INTO `features_event` VALUES ('event_seminaries_desc','Wisembly donne la parole à tous les participants de votre séminaire. Collectez toutes les questions et répondez mieux à leurs attentes !'),('event_seminaries_title','Faites participer votre public'),('feedback_survey_desc','<p>Wisembly intègre un editeur d’enquête de satisfaction qui vous permet de collecter du feedback à tout moment directement via notre plateforme. Contrairement aux questionnaires “papier” ou aux mails envoyés après coup, les enquêtes de satisfaction Wisembly vous assure d’un taux de réponse maximum.</p>\r\n						<p>Collectez du feedback à chaque événement et suivez l’évolution sur Wisembly afin d’adapter au mieux le contenu aux attentes du public.</p>'),('feedback_survey_link','Enquête de satisfaction'),('feedback_survey_title','Améliorez vos événements au fur et à mesure'),('fullscreen_desc','Afficher les messages du public en salle permet de booster les interactions tout en mettant en valeur les réactions de l’audience. Vous pouvez jongler entre les slides et les questions, choisir le mode d’affichage et personnaliser les couleurs et le logo de votre écran.'),('fullscreen_link','Fullscreen'),('fullscreen_title','Affichez un écran 100% interactif'),('interaction_analysis_desc1','Après chaque événement, Wisembly compile et analyse toute vos données: questions, commentaires, votes, nombre de participants, nuage de mots etc.'),('interaction_analysis_desc2','Depuis cette interface graphique, vous pourrez visualiser les faits marquants de votre événement et les exporter sous différents formats.'),('interaction_analysis_link','Analyse des interactions'),('interaction_analysis_title','Visualisez le contenu de votre événement'),('moderation_desc','Si vous le souhaitez, vous pouvez modérer les messages du public à priori. Dans ce cas, seules les messages que vous validez seront publiés. Vous pouvez également modérer les messages a posteriori si vous changez d’avis.'),('moderation_link','Modération'),('moderation_title','Modérez les messages du public'),('multi_devices_desc1','Pourquoi changer les habitudes de votre public en leur distribuant des boîtiers ou autres appareils encombrant ?'),('multi_devices_desc2','<p>Web, mobile, tablette, Twitter, email, SMS...</p>\r\n						<p>Wisembly fonctionne depuis tous les appareils nés après le minitel.</p>'),('multi_devices_desc3','L’audience peuvent utiliser le device avec lequel il se sent à l’aise c’est à dire celui qui est déjà dans leur poche.'),('multi_devices_link','Multi-devices'),('multi_devices_title','Wisembly marche partout. Point.'),('qna_desc1','<p>Sans vous interrompre, de manière anonyme ou non, le public peut partager ses questions et ses réactions avec son téléphone mobile.</p>\r\n									<p>Nous avons participé à beaucoup d’événements avant de concevoir Wisembly, comme nous, vous devez en avoir marre des timides qui n’osent pas poser de questions ou de ceux qui monopolisent le micro pendant de longues minutes...</p>'),('qna_desc2','Avec Wisembly, tout le monde peut s’exprimer, c’est vous qui selectionnez les meilleures questions.'),('qna_link','Questions & commentaires'),('qna_title','Laissez s’exprimer votre public'),('question_answers_desc','Vous n’aurez sûrement pas le temps de répondre à toutes les questions de l’audience durant le séminaire. Pourquoi ne pas répondre au questions directement sur Wisembly? Au fur et à mesure ou après l’événement, vous continuez ainsi le dialogue avec votre public et répondez totalement à leurs attentes.'),('question_answers_link','Réponses aux questions'),('question_answers_title','Continuez le dialogue avec votre audience'),('votes_desc','Vous avez l’habitude de distribuer des boîtiers de vote à vos participants ? Vous vous occupez de la location, de la caution, de la distribution ? Passez au numérique et permettez enfin à votre public d’utiliser l’appareil qu’ils ont déjà dans la poche. C’est beaucoup plus simple, moins cher et résolument plus moderne !'),('votes_link','Votes'),('votes_title','Oubliez les boîtiers de vote!');
/*!40000 ALTER TABLE `features_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `features_meeting`
--

DROP TABLE IF EXISTS `features_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features_meeting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features_meeting`
--

LOCK TABLES `features_meeting` WRITE;
/*!40000 ALTER TABLE `features_meeting` DISABLE KEYS */;
INSERT INTO `features_meeting` VALUES ('decision_taking_desc1','<p>Les réunions sont de parfaits moments pour prendre des décisions communes.</p>\r\n									<p>Pas la peine de faire un tour de table interminable sans arriver à une décision claire. Un simple clic sur Wisembly vous permet d’organiser un vote.</p>'),('decision_taking_desc2','<p>Le résultat est immédiat.</p>\r\n									<p>Vous gardez une trace de chacune des décisions prises dans vos différentes réunions.</p>'),('decision_taking_link','Votes / prise de décision'),('decision_taking_title','Prenez de vraies décisions durant vos réunions'),('documents_desc1','Arrêtez de jongler entre vos différentes présentations PowerPoint et les documents à envoyer par mail aux participants.'),('documents_desc2','Tout est rassemblé sur votre interface Wisembly, décidez en un clic de les projeter ou de les mettre à disposition de tous. Votre contenu est totalement sécurisé. Seuls les utilisaturs accrédités peuvent y accéder.'),('documents_link','Partage et visualisation de documents'),('documents_title','Tous les supports de votre réunion centralisés à un même endroit'),('feedback_survey_desc1','Pourquoi ne pas profiter de vos participants pour continuer à récolter du feedback à la fin de votre réunion ?'),('feedback_survey_desc2','Avec Wisembly, vous pouvez très rapidement récolter leur opinion sur le déroulé de la réunion, sur les sujets abordés et les décisions qui ont été prises.'),('feedback_survey_desc3','Quelques clics suffisent à identifier les points encore flous et à améliorer vos prochaines réunions.'),('feedback_survey_link','Enquête de satisfaction'),('feedback_survey_title','Améliorez vos réunions au fur et à mesure'),('meeting_confcalls_desc','Wisembly aide des centaines d’entreprises à mieux préparer, animer et assurer le suivi de leurs réunions & conf-call.'),('meeting_confcalls_title','Boostez vos réunions'),('multi_devices_desc','<p>Pourquoi perdre du temps avec des explications interminables en début de réunion?</p>\r\n						<p>Vos participants se connectent avec le device de leur choix (téléphone, smartphone, tablette, PC). Aucun compte à créer, pas de logiciel à télécharger.</p>\r\n						<p>L’accès est immédiat et intuitif.</p>'),('multi_devices_link','Multi-devices'),('multi_devices_title','Vos participants sont déjà équipés'),('questions_and_ideas_desc1','<p>Chaque participant peut à tout moment poser réagir ou poser une question sur le sujet traité sans interrompre la présentation.</p>\r\n									<p>Vous ne passez à côté d’aucune idée pertinente.</p>'),('questions_and_ideas_desc2','<p>Les participants se sentent impliqués et écoutés lors de vos réunions.</p>\r\n									<p>Tout le monde suit la réunion et reste impliqué.</p>'),('questions_and_ideas_link','Remontée de questions & idées'),('questions_and_ideas_title','Vos participants sont impliqués et restent concentrés'),('schedule_link','Ordre du jour'),('schedule_meetings_desc','<p>Préparez l’agenda de votre réunion en fonction des sujets à traiter.</p>\r\n						<p>Partagez l’ordre du jour avec l’ensemble des personnes qui participent à la réunion.</p>\r\n						<p>Retrouvez facilement les idées, propositions et décisions prises sur les différents sujets traités.</p>'),('schedule_meetings_title','Organisez vos réunions point par point'),('statistics_desc','<p>Wisembly garde en mémoire tout ce qui s’est passé durant votre réunion.</p>\r\n						<p>Retrouvez rapidement les sujets traités, les documents partagés, les questions soulevées et les décisions qui ont été prises.</p>\r\n						<p>Wisembly devient la mémoire de vos réunions.</p>'),('statistics_link','Statistiques & comptes-rendus'),('statistics_title','Gardez une trace de chacune de vos réunions');
/*!40000 ALTER TABLE `features_meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `features_training`
--

DROP TABLE IF EXISTS `features_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features_training` (
  `key` varchar(255) COLLATE utf8_bin NOT NULL,
  `value` text COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features_training`
--

LOCK TABLES `features_training` WRITE;
/*!40000 ALTER TABLE `features_training` DISABLE KEYS */;
INSERT INTO `features_training` VALUES ('classes_trainings_desc1','Wisembly vous permet de rythmer vos formations.'),('classes_trainings_desc2','Vos élèves s\'approprient le contenu. Vous suivez leur évolution.'),('classes_trainings_title','Cours et formations'),('documents_management_desc','Arrêtez de jongler entre vos différentes présentations PowerPoint et les documents à distribuer aux élèves. Tout est centralisé sur une seule interface. Projetez les ou partagez les avec vos élèves en un seul clic.'),('documents_management_link','Gestion des documents'),('documents_management_title','Tous les supports de votre formation centralisés à un même endroit'),('multi_device_desc1','Pourquoi changer les habitudes de vos élèves en leur distribuant des boîtiers ou autres appareils encombrants ?'),('multi_device_desc2','<p>Web, mobile, tablette, Twitter, email, SMS...</p>\r\n						<p>Wisembly fonctionne depuis tous les appareils nés après le minitel.</p>'),('multi_device_desc3','Vos élèves peuvent utiliser le device avec lequel ils se sentent à l’aise c’est à dire celui qu’ils ont sur eux.'),('multi_device_title','Vos élèves sont déjà équipés'),('multi_devices_link','Multi-device'),('qna_desc','<p>Il n’y a pas de commentaire ou de question bête. Chaque question devrait être traitée.</p>\r\n						<p>Avec Wisembly, vos élèves peuvent à tout moment poser leurs questions sans interrompre le cours.</p>\r\n						<p>Ils peuvent aussi réagir aux présentations des autres stagiaires et éventuellement partager des informations complémentaires.</p>\r\n						<p>Vous pouvez traiter les questions en direct, à la fin du cours, ou bien après le cours directement sur votre Wiz.</p>'),('qna_link','Q&A'),('qna_title','Répondez à toutes les questions de vos élèves'),('quiz_link','Quiz'),('quizzes_desc','Ponctuez votre cours à l’aide de questions rapides. Assurez que les notions présentées ont bien été comprises et que tout le monde suit. Préparées à l’avance, ces questions sont très efficaces pour booster l’attention et rythmer votre formation.'),('quizzes_title','Assurez-vous que tout le monde suit'),('stats_reporting_desc1','Après chaque session, vous avez accès à une analyse détaillée de votre formation: volume et type d’interactions, contenus, classement des élèves, notes moyenne etc.'),('stats_reporting_desc2','<p>Il devient facile de retrouver les questions, les slides et les notes d’une formation vieille d’il y a plusieurs mois en quelques secondes et de “rejouer” le cours.</p>\r\n						<p>Wisembly devient la mémoire de toutes vos formations.</p>'),('stats_reporting_link','Stats & reporting'),('stats_reporting_title','La mémoire de vos formations'),('students_evaluation_desc1','<p>Il n’est pas normal que vous que vous perdiez un temps précieux à corriger vos QCM d\'évaluation. Grâce à Wisembly, tout est automatique.</p>\r\n									<p>Vous concevez simplement vos évaluations: questions ouvertes, questions à choix multiples, questions à choix unique...</p>\r\n									<p>Vos élèves y répondent directement depuis leur téléphone, tablette ou PC.</p>'),('students_evaluation_desc2','<p>La correction est effectuée automatiquement.</p>\r\n									<p>Vos étudiants accèdent immédiatement à leurs résultats ainsi qu’à la liste de bonnes réponses.</p>\r\n									<p>Vous avez accès aux réponses et aux notes de chacun ainsi qu’aux résultats de l’ensemble de la classe.</p>'),('students_evaluation_link','Evaluations des élèves'),('students_evaluation_title','Vos évaluations sont corrigées immédiatement'),('training_evaluation_desc','<p>Vous pouvez demander à vos élèves de donner leur opinion sur votre cours.</p>\r\n						<p>Les résultats sont directement compilés sur la plateforme et vous n’avez pas à les retranscrire depuis des formulaires papiers. Tous les résultats sont exportables sous excel.</p>\r\n						<p>Vous avez ainsi une vision d’ensemble sur votre cours et pouvez adapter le contenu aux attentes et profils des particpants.</p>'),('training_evaluation_title','Améliorez vos formations avec vos élèves'),('trainings_evaluation_link','Evaluation des formations');
/*!40000 ALTER TABLE `features_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage`
--

DROP TABLE IF EXISTS `homepage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homepage` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage`
--

LOCK TABLES `homepage` WRITE;
/*!40000 ALTER TABLE `homepage` DISABLE KEYS */;
INSERT INTO `homepage` VALUES ('discover_our_happy_clients','Découvrez nos <strong>400</strong> heureux clients et leurs avis'),('discover_wisembly_for','Découvrez Wisembly pour les :'),('events','Evénements'),('formations','Formations'),('homepage_baseline','Wisembly est une solution web & mobile qui vous permet de préparer, d’animer et d’assurer le suivi de vos réunions.'),('homepage_title','Collaborez en réunion'),('meetings','Réunions'),('quote_dias','Tout le monde a adoré : c\'est une manière d\'intervenir qui n\'existait pas avant [...] Wisembly permet d\'aller au-delà de la présentation et d\'ouvrir le dialogue.'),('testimonials','Témoignages');
/*!40000 ALTER TABLE `homepage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `key` varchar(255) COLLATE utf8_bin NOT NULL,
  `value` text COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES ('about','À propos'),('api','APIs'),('back','Retour'),('case_context_title','Le contexte'),('case_results_title','Les résultats'),('case_studies_global_page_desc','Wisembly aide des centaines d’entreprise à collaborer en réunion et à booster leur productivité.'),('case_studies_global_page_title','Comme nos clients: gagnez en productivité durant vos meetings'),('case_studies_menu_title','Etudes de cas'),('case_usage_title','L\'utilisation de Wisembly'),('classes_an_trainings_menu_title','Cours et formations'),('clients','Clients'),('contact','Contact'),('contact_us_number','Contactez nous au <strong>%number%</strong>'),('developers','Développeurs'),('email','E-mail'),('event_keyword','Event keyword'),('events_and_seminaries_menu_title','Événements et séminaires'),('free_trial','Essai gratuit'),('jobs','Recrutement'),('join_an_event','Join an event'),('join_event_button','Join'),('login','Login'),('login_button','Login'),('meetings_and_confcalls_menu_title','Réunions et conf-calls'),('password','Password'),('plans_menu_title','Plans'),('read_case_study_link','Lire l\'étude de cas'),('resources','Ressources'),('social','Communauté'),('suscribe','S\'abonner'),('try_for_free','Essayez gratuitement'),('widget','Widget'),('write_to_us','Ecrivez-nous');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-09-02 11:42:34
