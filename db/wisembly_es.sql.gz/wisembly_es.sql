-- MySQL dump 10.13  Distrib 5.5.29, for osx10.6 (i386)
--
-- Host: localhost    Database: wisembly_es
-- ------------------------------------------------------
-- Server version	5.5.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `features_training`
--

DROP TABLE IF EXISTS `features_training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features_training` (
  `key` varchar(255) COLLATE utf8_bin NOT NULL,
  `value` text COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features_training`
--

LOCK TABLES `features_training` WRITE;
/*!40000 ALTER TABLE `features_training` DISABLE KEYS */;
INSERT INTO `features_training` VALUES ('classes_trainings_desc1','Wisembly vous permet de rythmer vos formations.'),('classes_trainings_desc2','Vos élèves s\'approprient le contenu. Vous suivez leur évolution.'),('classes_trainings_title','Cours et formations'),('documents_management_desc','Arrêtez de jongler entre vos différentes présentations PowerPoint et les documents à distribuer aux élèves. Tout est centralisé sur une seule interface. Projetez les ou partagez les avec vos élèves en un seul clic.'),('documents_management_link','Gestion des documents'),('documents_management_title','Tous les supports de votre formation centralisés à un même endroit'),('multi_device_desc1','Pourquoi changer les habitudes de vos élèves en leur distribuant des boîtiers ou autres appareils encombrants ?'),('multi_device_desc2','<p>Web, mobile, tablette, Twitter, email, SMS...</p>\r\n						<p>Wisembly fonctionne depuis tous les appareils nés après le minitel.</p>'),('multi_device_desc3','Vos élèves peuvent utiliser le device avec lequel ils se sentent à l’aise c’est à dire celui qu’ils ont sur eux.'),('multi_device_title','Vos élèves sont déjà équipés'),('multi_devices_link','Multi-device'),('qna_desc','<p>Il n’y a pas de commentaire ou de question bête. Chaque question devrait être traitée.</p>\r\n						<p>Avec Wisembly, vos élèves peuvent à tout moment poser leurs questions sans interrompre le cours.</p>\r\n						<p>Ils peuvent aussi réagir aux présentations des autres stagiaires et éventuellement partager des informations complémentaires.</p>\r\n						<p>Vous pouvez traiter les questions en direct, à la fin du cours, ou bien après le cours directement sur votre Wiz.</p>'),('qna_link','Q&A'),('qna_title','Répondez à toutes les questions de vos élèves'),('quiz_link','Quiz'),('quizzes_desc','Ponctuez votre cours à l’aide de questions rapides. Assurez que les notions présentées ont bien été comprises et que tout le monde suit. Préparées à l’avance, ces questions sont très efficaces pour booster l’attention et rythmer votre formation.'),('quizzes_title','Assurez-vous que tout le monde suit'),('stats_reporting_desc1','Après chaque session, vous avez accès à une analyse détaillée de votre formation: volume et type d’interactions, contenus, classement des élèves, notes moyenne etc.'),('stats_reporting_desc2','<p>Il devient facile de retrouver les questions, les slides et les notes d’une formation vieille d’il y a plusieurs mois en quelques secondes et de “rejouer” le cours.</p>\r\n						<p>Wisembly devient la mémoire de toutes vos formations.</p>'),('stats_reporting_link','Stats & reporting'),('stats_reporting_title','La mémoire de vos formations'),('students_evaluation_desc1','<p>Il n’est pas normal que vous que vous perdiez un temps précieux à corriger vos QCM d\'évaluation. Grâce à Wisembly, tout est automatique.</p>\r\n									<p>Vous concevez simplement vos évaluations: questions ouvertes, questions à choix multiples, questions à choix unique...</p>\r\n									<p>Vos élèves y répondent directement depuis leur téléphone, tablette ou PC.</p>'),('students_evaluation_desc2','<p>La correction est effectuée automatiquement.</p>\r\n									<p>Vos étudiants accèdent immédiatement à leurs résultats ainsi qu’à la liste de bonnes réponses.</p>\r\n									<p>Vous avez accès aux réponses et aux notes de chacun ainsi qu’aux résultats de l’ensemble de la classe.</p>'),('students_evaluation_link','Evaluations des élèves'),('students_evaluation_title','Vos évaluations sont corrigées immédiatement'),('training_evaluation_desc','<p>Vous pouvez demander à vos élèves de donner leur opinion sur votre cours.</p>\r\n						<p>Les résultats sont directement compilés sur la plateforme et vous n’avez pas à les retranscrire depuis des formulaires papiers. Tous les résultats sont exportables sous excel.</p>\r\n						<p>Vous avez ainsi une vision d’ensemble sur votre cours et pouvez adapter le contenu aux attentes et profils des particpants.</p>'),('training_evaluation_title','Améliorez vos formations avec vos élèves'),('trainings_evaluation_link','Evaluation des formations');
/*!40000 ALTER TABLE `features_training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `key` varchar(255) COLLATE utf8_bin NOT NULL,
  `value` text COLLATE utf8_bin NOT NULL,
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES ('about','À propos'),('api','APIs'),('case_studies_menu_title','Etudes de cas'),('classes_an_trainings_menu_title','Cours et formations'),('contact','Contact'),('contact_us_number','Contactez nous au <strong>%number%</strong>'),('developers','Développeurs'),('email','E-mail'),('event_keyword','Event keyword'),('events_and_seminaries_menu_title','Événements et séminaires'),('free_trial','Essai gratuit'),('jobs','Recrutement'),('join_an_event','Join an event'),('join_event_button','Join'),('login','Login'),('login_button','Login'),('meetings_and_confcalls_menu_title','Réunions et conf-calls'),('password','Password'),('plans_menu_title','Plans'),('resources','Ressources'),('social','Communauté'),('suscribe','S\'abonner'),('try_for_free','Essayez gratuitement'),('widget','Widget'),('write_to_us','Ecrivez-nous');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-09-01 22:33:36
